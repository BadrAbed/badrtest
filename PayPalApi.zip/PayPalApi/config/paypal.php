<?php
return [
    'username'=>'badrabed66-facilitator_api1.gmail.com',
    'password'=>'YWLGYWKCAMYUC3Y3',
    'Signature'=>'Ajiy6YmBz00sV0oT2S-obuaQ3kehAIbLN3rRWcygQKpLBZzLxJszMmev',
    'client_id' => 'AS89_BH-7w-p2jCf5X5Rw_LI9DDuJBY-4mIobi2FAl8lbO9Rbei3QT_UMxyahJ4u1rUNQ4lsoXm6d41y',
    'secret' => 'EEpfsYxVQJIflRNz2OAL54jljJ9-YiZf0jX5926-1OQNhhwoEsxs4TMwAJ_xR7JtjYBkvaAV75jePnpV',
    'mode' => 'sandbox',
    'link_mode' => 'https://api.sandbox.paypal.com' // ||https://api.paypal.com

];