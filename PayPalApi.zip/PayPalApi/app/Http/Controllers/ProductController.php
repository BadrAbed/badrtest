<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function payNow($id)
    {
        $product = Product::find($id);
        if ($product) {
            $pay_pal_class = new pal();
            return $pay_pal_class->getCheckout($product->price);

        }
    }

    static function getDone(Request $request)
    {

        // Clear the shopping cart, write to database, send notifications, etc.

        // Thank the user for the purchase
        $pay_pal_class = new pal();
        //  $pay_pal_class->getDone($request);
        return dd($pay_pal_class->getDone($request));
        //return view('checkout.done');
    }

    static function getCancel()
    {

    }
}
