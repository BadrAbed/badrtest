<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Paypal;
use Redirect;

class pal extends Controller
{
    private $_apiContext;

    public function __construct()
    {
        $this->generateRequestId();
        $this->_apiContext = Paypal::ApiContext(
            config('paypal.client_id'),
            config('paypal.secret'));
//            config('paypal.password'),
//            config('paypal.username'),
//            config('paypal.Signature'));

        $this->_apiContext->setConfig(array(
            'mode' => config('paypal.mode'),
            'service.EndPoint' => config('paypal.link_mode'),
            'http.ConnectionTimeOut' => 200000,
            'log.LogEnabled' => true,
            'log.FileName' => storage_path('logs/paypal.log'),
            'log.LogLevel' => 'FINE'
        ));

    }

    public function getCheckout($price)
    {
        $payer = Paypal::Payer();
        $payer->setPaymentMethod('paypal');

        $amount = Paypal:: Amount();
        $amount->setCurrency('USD');
        $amount->setTotal($price); // This is the simple way,
        // you can alternatively describe everything in the order separately;
        // Reference the PayPal PHP REST SDK for details.

        $transaction = Paypal::Transaction();
        $transaction->setAmount($amount);
        $transaction->setDescription('What are you selling?');

        $redirectUrls = Paypal:: RedirectUrls();
        $redirectUrls->setReturnUrl(url('done/payPal'));
        $redirectUrls->setCancelUrl(url('cancel/payPal'));

        $payment = Paypal::Payment();
        $payment->setIntent('sale');
        $payment->setPayer($payer);
        $payment->setRedirectUrls($redirectUrls);
        $payment->setTransactions(array($transaction));
        $this->_apiContext->resetRequestId();
        $response = $payment->create($this->_apiContext);

        $redirectUrl = $response->links[1]->href;

        return Redirect::to($redirectUrl);
    }

    public function getDone(Request $request)
    {
        $id = $request->get('paymentId');
        $token = $request->get('token');

        $payer_id = $request->get('PayerID');

        $payment = PayPal::getById($id, $this->_apiContext);

        $paymentExecution = PayPal::PaymentExecution();

        $paymentExecution->setPayerId($payer_id);
//
        $executePayment = $payment->execute($paymentExecution, $this->_apiContext);

        // Clear the shopping cart, write to database, send notifications, etc.

        // Thank the user for the purchase
        echo 'done';
    }

    private function generateRequestId()
    {
        static $pid = -1;
        static $addr = -1;
        if ($pid == -1) {
            $pid = getmypid();
        }
        if ($addr == -1) {
            if (array_key_exists('SERVER_ADDR', $_SERVER)) {
                $addr = ip2long($_SERVER['SERVER_ADDR']);
            } else {
                $addr = php_uname('n');
            }
        }
        return $addr . $pid . $_SERVER['REQUEST_TIME'] . mt_rand(0, 0xffff);
    }
}
